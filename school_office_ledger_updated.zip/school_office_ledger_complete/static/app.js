document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("form[data-confirm]").forEach(form => {
    form.addEventListener("submit", event => {
      if (!window.confirm(form.dataset.confirm || "Continue?")) event.preventDefault();
    });
  });
  const type = document.getElementById("transactionType");
  if (type) {
    type.addEventListener("change", () => {
      const label = type.value === "receipt" ? "Cash Receipt / Collection" : "Cash Disbursement / Expense";
      type.setAttribute("aria-label", label);
    });
  }
});
