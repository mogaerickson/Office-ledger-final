# School Office Ledger — Updated Complete Source

Technology: Python Flask, HTML/CSS/JavaScript, SQLite.

## What was changed (keeping the existing pages/features)
- New self-registered accounts are assigned the Editor role, so each user can create their own projects and reports without an Owner/Admin approving the account.
- A project is created under the signed-in user. Users can create reports inside their own projects.
- Each report is owned by the user who created it. The creator can view/edit its transactions and liquidation entries.
- The report creator can share an individual report with another account as `Viewer` (read-only) or `Editor` (can add/delete transactions and liquidation entries).
- A user sees their own reports and reports explicitly shared with them on the Dashboard and Cash Ledger.
- The backend checks report permissions on viewing, exporting, and modifying report data; hiding buttons alone is not used as the security boundary.
- Existing project/report, cash receipt/disbursement, liquidation, CSV export, activity log, and user management pages remain in the source.

## Run in GitHub Codespaces
Open a terminal in the folder containing `app.py` and `requirements.txt`, then run:

```bash
python -m pip install -r requirements.txt
python app.py
```

Open the **Ports** tab, make port `5000` visible, and open its forwarded URL.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

## Notes
- SQLite database and uploaded-file directories are created under `instance/` at runtime.
- Existing accounts already stored in an old database keep their existing roles. New registrations receive Editor.
- This is a development/MVP build, not a production security certification. Set a strong `SECRET_KEY`, add CSRF protection, HTTPS, backups, and conduct further testing before using real financial data.
- Automated tests are in `tests/`. Run them with `python -m unittest discover -s tests -v` after installing requirements.
