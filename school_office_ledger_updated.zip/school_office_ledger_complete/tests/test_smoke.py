"""Automated smoke tests. Run with: python -m unittest discover -s tests -v"""
import os
import tempfile
import unittest

_TEMP_DIR = tempfile.TemporaryDirectory()
os.environ["DATABASE_PATH"] = os.path.join(_TEMP_DIR.name, "test-ledger.db")
from app import app, init_db, get_db  # noqa: E402


class LedgerSmokeTest(unittest.TestCase):
    def setUp(self):
        app.config.update(TESTING=True, SECRET_KEY="test-secret")
        with app.app_context():
            db = get_db()
            db.execute("PRAGMA foreign_keys = OFF")
            for table in ("activity_logs", "liquidation_items", "transactions", "reports", "projects", "users"):
                db.execute(f"DELETE FROM {table}")
            db.execute("DELETE FROM sqlite_sequence")
            db.execute("INSERT INTO users(username,full_name,password_hash,role) VALUES(?,?,?,?)",
                       ("owner", "System Owner", __import__("werkzeug.security", fromlist=["generate_password_hash"]).generate_password_hash("ChangeMe123!"), "Owner"))
            db.commit()
        self.client = app.test_client()

    def login_owner(self):
        return self.client.post("/login", data={"username": "owner", "password": "ChangeMe123!"}, follow_redirects=True)

    def test_full_workflow_sidebar_ledger_and_export(self):
        response = self.login_owner()
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Dashboard", response.data)
        self.assertIn(b"Cash Ledger", response.data)
        self.assertIn(b"Projects & Reports", response.data)

        response = self.client.post("/projects", data={"name": "Demo Project", "description": "Smoke test"}, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Demo Project", response.data)

        response = self.client.post("/projects/1/reports/new", data={"title": "Test Cash Report", "report_date": "2026-10-09"}, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Test Cash Report", response.data)

        for transaction_type, reference, description, amount in (
            ("receipt", "OR-001", "Test collection", "1000"),
            ("disbursement", "DV-001", "Test expense", "250"),
        ):
            response = self.client.post("/reports/1/transactions/new", data={
                "transaction_type": transaction_type, "transaction_date": "2026-10-09",
                "reference_no": reference, "description": description,
                "category": "School Project", "amount": amount,
            }, follow_redirects=True)
            self.assertEqual(response.status_code, 200)
            self.assertIn(description.encode(), response.data)

        response = self.client.post("/reports/1/liquidation/new", data={
            "item_date": "2026-10-09", "reference_no": "DV-001",
            "description": "Liquidation test item", "amount": "250", "notes": "Test note",
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Liquidation test item", response.data)

        response = self.client.get("/reports/1")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"750.00", response.data)

        response = self.client.get("/ledger")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Test Cash Report", response.data)
        response = self.client.get("/dashboard?q=Test+Cash+Report")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Test Cash Report", response.data)
        response = self.client.get("/reports/1/export.csv")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Test collection", response.data)
        self.assertIn(b"text/csv", response.content_type.encode())

    def test_bad_login_rejected_and_private_user_admin_page(self):
        response = self.client.post("/login", data={"username": "owner", "password": "wrong-password"}, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Mali ang username", response.data)

    def test_amount_nan_is_rejected(self):
        self.login_owner()
        self.client.post("/projects", data={"name": "P"}, follow_redirects=True)
        self.client.post("/projects/1/reports/new", data={"title": "R", "report_date": "2026-10-09"}, follow_redirects=True)
        response = self.client.post("/reports/1/transactions/new", data={
            "transaction_type": "receipt", "transaction_date": "2026-10-09",
            "description": "bad amount", "amount": "nan",
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertNotIn(b"bad amount</td>", response.data)


if __name__ == "__main__":
    unittest.main(verbosity=2)
