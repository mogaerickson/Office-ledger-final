import os, sqlite3, math, csv, io
from functools import wraps
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash, g, abort
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(BASE_DIR, "instance", "ledger.db"))
UPLOAD_DIR = os.path.join(BASE_DIR, "instance", "uploads")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-development-secret-key")
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = UPLOAD_DIR
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "pdf"}

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        full_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('Owner','Editor','Viewer')),
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT DEFAULT '',
        owner_id INTEGER NOT NULL REFERENCES users(id),
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        report_date TEXT NOT NULL,
        prepared_by TEXT DEFAULT '',
        checked_by TEXT DEFAULT '',
        audited_by TEXT DEFAULT '',
        approved_by TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        created_by INTEGER NOT NULL REFERENCES users(id),
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
        transaction_type TEXT NOT NULL CHECK(transaction_type IN ('receipt','disbursement')),
        transaction_date TEXT NOT NULL,
        reference_no TEXT DEFAULT '',
        description TEXT NOT NULL,
        category TEXT DEFAULT '',
        amount REAL NOT NULL CHECK(amount >= 0),
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS liquidation_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
        item_date TEXT NOT NULL,
        description TEXT NOT NULL,
        reference_no TEXT DEFAULT '',
        amount REAL NOT NULL CHECK(amount >= 0),
        notes TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS report_permissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        permission TEXT NOT NULL CHECK(permission IN ('Viewer','Editor')),
        granted_by INTEGER NOT NULL REFERENCES users(id),
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(report_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS activity_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id),
        action TEXT NOT NULL,
        details TEXT DEFAULT '',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    """)
    count = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if count == 0:
        db.execute("INSERT INTO users(username,full_name,password_hash,role) VALUES(?,?,?,?)",
                   ("owner", "System Owner", generate_password_hash("ChangeMe123!"), "Owner"))
    db.commit()
    db.close()

def report_access(report_id, user_id=None):
    """Return own/shared report access: Owner (creator), Editor, Viewer, or None."""
    user_id = user_id or session.get("user_id")
    row = get_db().execute("SELECT created_by FROM reports WHERE id=?", (report_id,)).fetchone()
    if not row:
        return None
    if row["created_by"] == user_id:
        return "Owner"
    share = get_db().execute("SELECT permission FROM report_permissions WHERE report_id=? AND user_id=?",
                             (report_id, user_id)).fetchone()
    return share["permission"] if share else None

def can_edit_report(report_id):
    return report_access(report_id) in ("Owner", "Editor")

def require_report_access(report_id, edit=False):
    access = report_access(report_id)
    if access is None:
        abort(403)
    if edit and access not in ("Owner", "Editor"):
        abort(403)
    return access

def log_action(action, details=""):
    user_id = session.get("user_id")
    get_db().execute("INSERT INTO activity_logs(user_id,action,details) VALUES(?,?,?)",
                     (user_id, action, details))
    get_db().commit()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def roles_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not session.get("user_id"):
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return decorator

@app.context_processor
def inject_user():
    return {"current_user": session.get("full_name"), "current_role": session.get("role"), "current_user_id": session.get("user_id")}

@app.route("/")
def index():
    if not session.get("user_id"):
        return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route("/register", methods=["GET", "POST"])
def register():
    # Every self-registered user can create their own projects and reports.
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        if not username or not full_name or len(password) < 8:
            flash("Ilagay ang lahat ng detalye. Dapat hindi bababa sa 8 characters ang password.", "error")
            return render_template("register.html")
        try:
            get_db().execute("INSERT INTO users(username,full_name,password_hash,role) VALUES(?,?,?,?)",
                             (username, full_name, generate_password_hash(password), "Editor"))
            get_db().commit()
            flash("Nagawa ang account. Maaari ka nang gumawa ng sarili mong project at files pagkatapos mag-login.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("May gumagamit na ng username na iyan.", "error")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["full_name"] = user["full_name"]
            session["role"] = user["role"]
            log_action("login", f"{user['username']} logged in")
            return redirect(url_for("dashboard"))
        flash("Mali ang username o password.", "error")
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    log_action("logout", "User logged out")
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    search = request.args.get("q", "").strip()
    owner_id = request.args.get("owner", "").strip()

    # Dashboard displays reports created by this user or explicitly shared with them.
    sql = """SELECT r.id, r.title, r.report_date, r.created_at,
                    p.id AS project_id, p.name AS project_name,
                    u.id AS owner_id, u.full_name AS owner_name, u.username AS owner_username
             FROM reports r
             JOIN projects p ON p.id = r.project_id
             JOIN users u ON u.id = r.created_by
             LEFT JOIN report_permissions rp ON rp.report_id=r.id AND rp.user_id=?
             WHERE (r.created_by=? OR rp.user_id IS NOT NULL)"""
    params = [session["user_id"], session["user_id"]]
    if search:
        sql += " AND (r.title LIKE ? OR p.name LIKE ? OR u.full_name LIKE ? OR u.username LIKE ?)"
        term = f"%{search}%"
        params.extend([term, term, term, term])
    if owner_id.isdigit():
        sql += " AND u.id = ?"
        params.append(int(owner_id))
    sql += " ORDER BY r.created_at DESC, r.id DESC"

    saved_files = db.execute(sql, params).fetchall()
    accounts = db.execute(
        "SELECT id, full_name, username FROM users ORDER BY full_name COLLATE NOCASE"
    ).fetchall()
    return render_template("dashboard.html", saved_files=saved_files, accounts=accounts,
                           search=search, selected_owner=owner_id)

@app.route("/users", methods=["GET", "POST"])
@login_required
@roles_required("Owner")
def users():
    db = get_db()
    if request.method == "POST":
        if session.get("role") != "Owner":
            abort(403)
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "Viewer")
        if role not in ("Owner", "Editor", "Viewer") or len(password) < 8 or not username or not full_name:
            flash("Suriin ang user details at gumamit ng password na 8+ characters.", "error")
        else:
            try:
                db.execute("INSERT INTO users(username,full_name,password_hash,role) VALUES(?,?,?,?)",
                           (username, full_name, generate_password_hash(password), role))
                db.commit()
                log_action("create_user", f"Created {username} as {role}")
                flash("Nagdagdag ng user.", "success")
            except sqlite3.IntegrityError:
                flash("Existing na ang username.", "error")
        return redirect(url_for("users"))
    rows = db.execute("SELECT id,username,full_name,role,created_at FROM users ORDER BY id").fetchall()
    return render_template("users.html", users=rows)

@app.route("/ledger")
@login_required
def ledger():
    db = get_db()
    search = request.args.get("q", "").strip()
    rows_sql = """SELECT r.id, r.title, r.report_date, r.created_at, p.name AS project_name,
        u.full_name AS creator_name,
        COALESCE(SUM(CASE WHEN t.transaction_type='receipt' THEN t.amount ELSE 0 END),0) AS receipts,
        COALESCE(SUM(CASE WHEN t.transaction_type='disbursement' THEN t.amount ELSE 0 END),0) AS disbursements
        FROM reports r JOIN projects p ON p.id=r.project_id JOIN users u ON u.id=r.created_by
        LEFT JOIN transactions t ON t.report_id=r.id
        LEFT JOIN report_permissions rp ON rp.report_id=r.id AND rp.user_id=?
        WHERE (r.created_by=? OR rp.user_id IS NOT NULL)"""
    params = [session["user_id"], session["user_id"]]
    if search:
        term = f"%{search}%"
        rows_sql += " AND (r.title LIKE ? OR p.name LIKE ? OR u.full_name LIKE ?)"
        params.extend([term, term, term])
    rows_sql += " GROUP BY r.id ORDER BY r.report_date DESC, r.id DESC"
    rows = db.execute(rows_sql, params).fetchall()
    return render_template("ledger.html", reports=rows, search=search)

@app.route("/reports/<int:report_id>/export.csv")
@login_required
def export_report_csv(report_id):
    db = get_db()
    report = db.execute("SELECT r.*, p.name AS project_name FROM reports r JOIN projects p ON p.id=r.project_id WHERE r.id=?", (report_id,)).fetchone()
    if not report:
        abort(404)
    require_report_access(report_id)
    transactions = db.execute("SELECT transaction_date, transaction_type, reference_no, description, category, amount FROM transactions WHERE report_id=? ORDER BY transaction_date, id", (report_id,)).fetchall()
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["School Office Ledger - Financial Report"])
    writer.writerow(["Project", report["project_name"]])
    writer.writerow(["Report", report["title"]])
    writer.writerow(["Report Date", report["report_date"]])
    writer.writerow([])
    writer.writerow(["Date", "Type", "Reference No.", "Description", "Category", "Amount (PHP)"])
    for item in transactions:
        writer.writerow([item["transaction_date"], item["transaction_type"], item["reference_no"], item["description"], item["category"], f'{item["amount"]:.2f}'])
    from flask import Response
    filename = "".join(ch for ch in report["title"] if ch.isalnum() or ch in (" ", "-", "_ ")).strip().replace(" ", "_") or f"report_{report_id}"
    return Response(output.getvalue(), mimetype="text/csv; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="{filename}.csv"'})

@app.route("/projects", methods=["GET", "POST"])
@login_required
def projects():
    db = get_db()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        description = request.form.get("description", "").strip()
        if not name:
            flash("Kailangan ang project name.", "error")
        else:
            db.execute("INSERT INTO projects(name,description,owner_id) VALUES(?,?,?)",
                       (name, description, session["user_id"]))
            db.commit()
            log_action("create_project", name)
            flash("Nagawa ang project.", "success")
        return redirect(url_for("projects"))
    rows = db.execute("""SELECT DISTINCT p.*,u.full_name owner_name FROM projects p
                         JOIN users u ON u.id=p.owner_id
                         LEFT JOIN reports r ON r.project_id=p.id
                         LEFT JOIN report_permissions rp ON rp.report_id=r.id AND rp.user_id=?
                         WHERE p.owner_id=? OR rp.user_id IS NOT NULL
                         ORDER BY p.created_at DESC""", (session["user_id"], session["user_id"])).fetchall()
    return render_template("projects.html", projects=rows)

@app.route("/projects/<int:project_id>")
@login_required
def project_detail(project_id):
    db = get_db()
    project = db.execute("""SELECT p.*,u.full_name owner_name FROM projects p
                            JOIN users u ON u.id=p.owner_id WHERE p.id=?""", (project_id,)).fetchone()
    if not project:
        abort(404)
    allowed_project = project["owner_id"] == session["user_id"] or db.execute(
        "SELECT 1 FROM reports r JOIN report_permissions rp ON rp.report_id=r.id WHERE r.project_id=? AND rp.user_id=? LIMIT 1",
        (project_id, session["user_id"])).fetchone()
    if not allowed_project:
        abort(403)
    reports = db.execute("""SELECT r.*,
        COALESCE((SELECT SUM(amount) FROM transactions t WHERE t.report_id=r.id AND t.transaction_type='receipt'),0) receipts,
        COALESCE((SELECT SUM(amount) FROM transactions t WHERE t.report_id=r.id AND t.transaction_type='disbursement'),0) disbursements
        FROM reports r LEFT JOIN report_permissions rp ON rp.report_id=r.id AND rp.user_id=?
        WHERE r.project_id=? AND (r.created_by=? OR rp.user_id IS NOT NULL)
        ORDER BY r.report_date DESC, r.id DESC""", (session["user_id"], project_id, session["user_id"])).fetchall()
    return render_template("project_detail.html", project=project, reports=reports)

@app.route("/projects/<int:project_id>/reports/new", methods=["GET", "POST"])
@login_required
def new_report(project_id):
    db = get_db()
    project = db.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
    if not project:
        abort(404)
    if project["owner_id"] != session["user_id"]:
        abort(403)
    if request.method == "POST":
        title = request.form.get("title", "").strip() or "Cash Receipts and Disbursements"
        report_date = request.form.get("report_date") or datetime.now().strftime("%Y-%m-%d")
        cur = db.execute("""INSERT INTO reports(project_id,title,report_date,prepared_by,checked_by,audited_by,approved_by,notes,created_by)
                            VALUES(?,?,?,?,?,?,?,?,?)""",
                         (project_id,title,report_date,request.form.get("prepared_by",""),
                          request.form.get("checked_by",""),request.form.get("audited_by",""),
                          request.form.get("approved_by",""),request.form.get("notes",""),session["user_id"]))
        db.commit()
        log_action("create_report", title)
        return redirect(url_for("report_detail", report_id=cur.lastrowid))
    return render_template("report_form.html", project=project, today=datetime.now().strftime("%Y-%m-%d"))

@app.route("/reports/<int:report_id>")
@login_required
def report_detail(report_id):
    db = get_db()
    report = db.execute("""SELECT r.*,p.name project_name FROM reports r
                           JOIN projects p ON p.id=r.project_id WHERE r.id=?""", (report_id,)).fetchone()
    if not report:
        abort(404)
    access = require_report_access(report_id)
    report = dict(report)
    report["access"] = access
    share_rows = db.execute("SELECT rp.user_id,rp.permission,u.full_name,u.username FROM report_permissions rp JOIN users u ON u.id=rp.user_id WHERE rp.report_id=? ORDER BY u.full_name", (report_id,)).fetchall() if access == "Owner" else []
    transactions = db.execute("SELECT * FROM transactions WHERE report_id=? ORDER BY transaction_date DESC,id DESC",
                              (report_id,)).fetchall()
    receipts = sum(t["amount"] for t in transactions if t["transaction_type"] == "receipt")
    disbursements = sum(t["amount"] for t in transactions if t["transaction_type"] == "disbursement")
    liquidation = db.execute("SELECT * FROM liquidation_items WHERE report_id=? ORDER BY item_date DESC,id DESC",
                             (report_id,)).fetchall()
    return render_template("report_detail.html", report=report, transactions=transactions,
                           receipts=receipts, disbursements=disbursements,
                           balance=receipts-disbursements, liquidation=liquidation, today=datetime.now().strftime("%Y-%m-%d"),
                           access=access, share_rows=share_rows, shareable_users=db.execute("SELECT id,full_name,username FROM users WHERE id != ? ORDER BY full_name", (session["user_id"],)).fetchall() if access == "Owner" else [])

@app.route("/reports/<int:report_id>/sharing", methods=["POST"])
@login_required
def share_report(report_id):
    db = get_db()
    report = db.execute("SELECT id,created_by,title FROM reports WHERE id=?", (report_id,)).fetchone()
    if not report:
        abort(404)
    if report["created_by"] != session["user_id"]:
        abort(403)
    user_id = request.form.get("user_id", type=int)
    permission = request.form.get("permission", "Viewer")
    if not user_id or user_id == session["user_id"] or permission not in ("Viewer", "Editor"):
        flash("Piliin ang ibang account at valid na permission.", "error")
    elif not db.execute("SELECT id FROM users WHERE id=?", (user_id,)).fetchone():
        flash("Hindi makita ang account.", "error")
    else:
        db.execute("INSERT INTO report_permissions(report_id,user_id,permission,granted_by) VALUES(?,?,?,?) ON CONFLICT(report_id,user_id) DO UPDATE SET permission=excluded.permission,granted_by=excluded.granted_by,created_at=CURRENT_TIMESTAMP",
                   (report_id, user_id, permission, session["user_id"]))
        db.commit()
        log_action("share_report", f"Shared report {report_id} with user {user_id} as {permission}")
        flash("Na-update ang file permission.", "success")
    return redirect(url_for("report_detail", report_id=report_id))

@app.route("/reports/<int:report_id>/sharing/<int:user_id>/remove", methods=["POST"])
@login_required
def unshare_report(report_id, user_id):
    db = get_db()
    report = db.execute("SELECT created_by FROM reports WHERE id=?", (report_id,)).fetchone()
    if not report:
        abort(404)
    if report["created_by"] != session["user_id"]:
        abort(403)
    db.execute("DELETE FROM report_permissions WHERE report_id=? AND user_id=?", (report_id, user_id))
    db.commit()
    log_action("unshare_report", f"Removed user {user_id} from report {report_id}")
    flash("Inalis ang access sa file.", "success")
    return redirect(url_for("report_detail", report_id=report_id))

@app.route("/reports/<int:report_id>/transactions/new", methods=["POST"])
@login_required
def add_transaction(report_id):
    db = get_db()
    exists = db.execute("SELECT id FROM reports WHERE id=?", (report_id,)).fetchone()
    if not exists:
        abort(404)
    require_report_access(report_id, edit=True)
    ttype = request.form.get("transaction_type")
    description = request.form.get("description", "").strip()
    try:
        amount = float(request.form.get("amount", "0"))
    except ValueError:
        amount = -1
    if ttype not in ("receipt", "disbursement") or not description or not math.isfinite(amount) or amount < 0:
        flash("Suriin ang uri, description, at amount.", "error")
    else:
        db.execute("""INSERT INTO transactions(report_id,transaction_type,transaction_date,reference_no,description,category,amount)
                      VALUES(?,?,?,?,?,?,?)""",
                   (report_id,ttype,request.form.get("transaction_date") or datetime.now().strftime("%Y-%m-%d"),
                    request.form.get("reference_no",""),description,request.form.get("category",""),amount))
        db.commit()
        log_action("add_transaction", f"{ttype}: {description} ({amount})")
        flash("Naisave ang transaction.", "success")
    return redirect(url_for("report_detail", report_id=report_id))

@app.route("/reports/<int:report_id>/transactions/<int:transaction_id>/delete", methods=["POST"])
@login_required
def delete_transaction(report_id, transaction_id):
    db = get_db()
    require_report_access(report_id, edit=True)
    db.execute("DELETE FROM transactions WHERE id=? AND report_id=?", (transaction_id, report_id))
    db.commit()
    log_action("delete_transaction", str(transaction_id))
    flash("Na-delete ang transaction kung mayroon itong tugmang ID.", "success")
    return redirect(url_for("report_detail", report_id=report_id))

@app.route("/reports/<int:report_id>/liquidation/new", methods=["POST"])
@login_required
def add_liquidation(report_id):
    db = get_db()
    if not db.execute("SELECT id FROM reports WHERE id=?", (report_id,)).fetchone():
        abort(404)
    require_report_access(report_id, edit=True)
    try:
        amount = float(request.form.get("amount", "0"))
    except ValueError:
        amount = -1
    description = request.form.get("description", "").strip()
    if not math.isfinite(amount) or amount < 0 or not description:
        flash("Suriin ang liquidation description at amount.", "error")
    else:
        db.execute("""INSERT INTO liquidation_items(report_id,item_date,description,reference_no,amount,notes)
                      VALUES(?,?,?,?,?,?)""",
                   (report_id,request.form.get("item_date") or datetime.now().strftime("%Y-%m-%d"),
                    description,request.form.get("reference_no",""),amount,request.form.get("notes","")))
        db.commit()
        log_action("add_liquidation_item", description)
        flash("Nadagdag ang liquidation item.", "success")
    return redirect(url_for("report_detail", report_id=report_id) + "#liquidation")

@app.route("/reports/<int:report_id>/liquidation/<int:item_id>/delete", methods=["POST"])
@login_required
def delete_liquidation(report_id, item_id):
    db = get_db()
    if not db.execute("SELECT id FROM reports WHERE id=?", (report_id,)).fetchone():
        abort(404)
    require_report_access(report_id, edit=True)
    cur = db.execute("DELETE FROM liquidation_items WHERE id=? AND report_id=?", (item_id, report_id))
    db.commit()
    if cur.rowcount:
        log_action("delete_liquidation_item", str(item_id))
        flash("Na-delete ang liquidation item.", "success")
    else:
        flash("Hindi nakita ang liquidation item.", "error")
    return redirect(url_for("report_detail", report_id=report_id) + "#liquidation")

@app.route("/activity")
@login_required
def activity():
    rows = get_db().execute("""SELECT a.*,u.full_name FROM activity_logs a
                               LEFT JOIN users u ON u.id=a.user_id
                               ORDER BY a.id DESC LIMIT 200""").fetchall()
    return render_template("activity.html", logs=rows)

@app.errorhandler(403)
def forbidden(_error):
    return render_template("error.html", code=403, message="Wala kang pahintulot para gawin ito."), 403

@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", code=404, message="Hindi makita ang record na hinahanap."), 404

with app.app_context():
    init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")
